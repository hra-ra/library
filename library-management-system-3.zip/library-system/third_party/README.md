`crow_all.h` is the single-header release (v1.3.4) of the Crow C++ web framework
(https://github.com/CrowCpp/Crow), used under its BSD-3-Clause licence. It is checked in so the
project builds without a package manager.

Crow needs the standalone Asio library, which you install with your package manager
(`libasio-dev` on Ubuntu, `asio` on Homebrew). This Crow version works with both older and
current Asio releases.
